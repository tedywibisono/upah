<?php $__env->startSection('container'); ?>
<h1>halaman customer</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.orimain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/upah/resources/views/customer/customer.blade.php ENDPATH**/ ?>