<?php

namespace App\Http\Controllers;

use App\Http\Requests\LoginRequest;
use App\Models\User;
use Illuminate\Contracts\Session\Session;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;


class LoginController extends Controller
{
    public function login(Request $req){
        return view("login");
    }
    
    public function auth(LoginRequest $req){
        $email= $req->email;
        $password= $req->password;
        $user = User::where('email', $email)->first();
    
        if (Hash::check($password, $user->password)){
            $apiToken = base64_encode(Str::random(40));
            User::where('email', $email)->update([
                'remember_token' => $apiToken
            ]);
            if (Auth::attempt(['email' => $email, 'password' => $password])){
                
                if (auth()->user()->id_level == 'admin') {
                    $req->session()->regenerate();
                    return redirect(url('admin'));
                }else if (auth()->user()->id_level == 'mitra'){
                    $req->session()->regenerate();
                    return redirect(url('mitra'));
                }else if (auth()->user()->id_level == 'customer'){
                    return redirect(url('customer'));
                }else{
                    return redirect(url('/'));
                };
            };
        }else{
                echo"<div class='alert alert-danger'>email dan password salah </div>";
                return view('login');
        };
        

        
       
    }
}
