@extends('layouts.orimain')


@section('container')
<h1>halaman admin</h1>
@endsection