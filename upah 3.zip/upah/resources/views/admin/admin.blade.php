@extends('layouts.orimain')


@section('container')
<h1>halaman admin</h1>
<a href="{{ url('signup')}}">buat aku mitra</a>
@endsection