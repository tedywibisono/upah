<?php $__env->startSection('container'); ?>
<h1>halaman admin</h1>
<a href="<?php echo e(url('signup')); ?>">buat aku mitra</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.orimain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/upah/resources/views/admin/admin.blade.php ENDPATH**/ ?>