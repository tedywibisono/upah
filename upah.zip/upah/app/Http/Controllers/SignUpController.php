<?php

namespace App\Http\Controllers;

use App\Http\Requests\RegisterMitraRequest;
use App\Http\Requests\SignUpRequest;
use App\Models\perusahaan;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class SignUpController extends Controller
{
    public function index(){
        return view('signup');
    }

    public function createMitra (RegisterMitraRequest $req){
        $nama_perusahaan = $req->perusahaan;
        $nama = $req->nama;
        $provinsi = $req->provinsi;
        $kota = $req->kota;
        $kecamatan = $req->kecamatan;
        $desa = $req->desa;
        $rt = $req->rt;
        $rw = $req->rw;
        $pin_mitra = $req->pin;
        $email = $req->email;
        $password = $req->password;
        $id_level = 'mitra';
        $code_perusahaan="PSH-" . strtotime(date("Y-m-d h:i:s"));

       
        $insert= new User;
            $insert->name = $nama;
            $insert->pin_mitra = $pin_mitra;
            $insert->email = $email;
            $insert->password = bcrypt($password);
            $insert->id_level = $id_level;
            $insert->code_perusahaan = $code_perusahaan;
            $insert->save();
        $insert = new perusahaan;
            $insert->code_perusahaan = $code_perusahaan;
            $insert->nama_perusahaan = $nama_perusahaan;
            $insert->provinsi = $provinsi;
            $insert->kota = $kota;
            $insert->kecamatan = $kecamatan;
            $insert->desa = $desa;
            $insert->rt = $rt;
            $insert->rw = $rw;
            $insert->save();

        return redirect(url("/login"))->with('success','Regristation successfull!! please login');
        
    }
    public function createCostumer(){
        
    }
}
