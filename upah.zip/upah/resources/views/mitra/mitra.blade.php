@extends('layouts.orimain')


@section('container')
@csrf
<h1>halaman mitra</h1>
@endsection