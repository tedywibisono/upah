@extends('layouts.orimain')


@section('container')
<h1>halaman customer</h1>
@endsection