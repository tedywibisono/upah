@extends('layouts.orimain')
@section('container')
<section class="login d-flex">
    <div class="login-left w-50 h-100 ">
        <img src="{{ asset('/img/login.png') }}" alt="">
    </div>
    <div class="login-right  w-50 ">
        <div class="row justify-content-center  ">
            <div class="col-6 ">
                <div class="header">
                    <h1>Welcome back</h1>
                    <p>Welcome back! Please enter your details.</p>
                </div>
                <div class="login-form ">
                    <form action="{{ url('daftar') }}" method="post">

                        @csrf
                        <div class="">
                            <label for="email" class="form-label">Email </label>
                            <input type="email" name="email" class="form-control @error('email') is-invalid @enderror" id="email" placeholder="Enter your email" required value="{{ old('email') }}">                            
                            @error('email')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                            @enderror
                        </div>
                        
                        <div>
                            <label for="Password" class="form-label">Password </label>
                            <input type="Password"name="password"class="form-control @error('password') is-invalid @enderror" id="Password" placeholder="Enter your password">
                            @error('password')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                        @enderror
                        </div>

                        <a href="#" class="text-decoration-none text-center">Forgot password</a>
                        <button class="sign-in"name="signin" type="submit">Login</button>
                    </form>
                   
                    <div class="text-center">
                        <span class="d-inline">buat akun mitra?<a href={{ url('signup')}} class="d-inline">Sign up for free</a></span>

                    </div>
                </div>

            </div>
        </div>
    </div>
@endsection