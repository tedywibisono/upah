<?php

use App\Http\Controllers\admin\AdminController;
use App\Http\Controllers\Customer\CustomerController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\mitra\MitraController;
use App\Http\Controllers\SignUpController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('home');
});
//Route Login
Route::get('/login',[LoginController::class,'login']);
Route::post('/daftar',[LoginController::class,'auth']);

//Route register
Route::get('/signup',[SignUpController::class,'index']);
Route::post('/register',[SignUpController::class,'createMitra']);

Route::group(['middleware'=>'is_admin:admin'], function(){

    Route::get('admin', [AdminController::class, 'Home'])->name('admin.home');
});
// halaman home admin

//halaman home mitra
Route::get('mitra',[MitraController::class, 'index'])->middleware('mitra');


//halaman home customer
Route::get('customer',[CustomerController::class, 'index'])->middleware('is_customer');


