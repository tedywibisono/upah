<?php $__env->startSection('container'); ?>
<section id = "hero">
    <div class="container h-100">
        <div class="row ">
            <div class="col-md-6 hero-tagline my-auto">
                <h1>IT`S TIME TO RECYCLE!</h1>
                <p><span> Upah </span> hadir sebagai bank sampah yang dapat menampung sampah di rumahmu dan anda dapat menabung menggunakan sampah yang ada di rumahmu </p>
                <a href="<?php echo e(url('login')); ?>"><button type="button" class="button-lg-primary">START NOW</button></a>
            </div>
        </div>
        <img src="<?php echo e(asset('img/atas.png')); ?>" alt="" class="position-absolute end-0 bottom-0 img-hero">
        <img src="<?php echo e(asset('img/truck.png')); ?>" alt="" class="position-absolute end-0 bottom-0 img-hero2">

    </div>
</section>

<section id ="recycle">
    <div class="container">
        <div class="row">
            <div class="col-md-4 text-center">
                <div class="card-kelola">
                    <div class="circle-icon position-relative mx-auto">
                        <img src="<?php echo e(asset('img/sampah.png')); ?>" alt="" class="position-absolute top-50 start-50 translate-middle">
                    </div>
                    <h3 class="mt-4">Kategori sampah</h3>
                    <p>Kategori sampah yang di terima di bank uang sampah</p>
                    <a href=""><button type="button" class="button-read mt-3"> selengkapnya</button></a>
                </div>
            </div>
            <div class="col-md-4 text-center">
                <div class="card-kelola">
                    <div class="circle-icon position-relative mx-auto">
                        <img src="<?php echo e(asset('img/jualsampah.png')); ?>" alt="" class="position-absolute top-50 start-50 translate-middle">
                    </div>
                    <h3 class="mt-4">Harga sampah</h3>
                    <p>Cek harga sampah mu disini.Semakin detail sampah yang kamu pilah, maka semakin tinggi nilai ekonominya.</p>
                    <a href=""><button type="button" class="button-read"> selengkapnya</button></a>
                </div>
            </div>
            <div class="col-md-4 text-center">
                <div class="card-kelola">
                    <div class="circle-icon position-relative mx-auto">
                        <img src="<?php echo e(asset('img/trucksampah.png')); ?>" alt="" class="position-absolute top-50 start-50 translate-middle">
                    </div>
                    <h3 class="mt-4">Penyetoran sampah</h3>
                    <p>Kirim langsung sampah ke Bank Uang Sampah atau tunggu truk sampah keliling kami.</p>
                    <a href=""><button type="button" class="button-read"> selengkapnya</button></a>
                </div>
            </div>
        </div>
    </div>
</section>



<section id="content">
    <section id ="info">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center mt-5 mb-2">
                    <h2>Tentang kami</h2>
                </div>
            </div>
            <div class="row mt-3">
    
                <div class="col-md-6">
                    <img src="<?php echo e(asset('img/aboutas.png')); ?>" alt="" class=" mt-5 img-aboutas">
                </div>
                <div class="col-md-6">
                    <p class="mt-5">Upah adalah sebuah gerakan inisiatif untuk memilah, mengumpulkan serta mengelola sampah. Kami mengundang seluruh lapisan masyarakat agar 
                        berpartisipasi bersama kami untuk membuat dampak lingkungan dan sosial
                         insidental yang positif di Indonesia.</p>
                </div>
            </div>
        </div>
    </section>
    
    <section id="layanan">
        <div class="container">
            <div class="row mt-5">
                <div class="col-md-4 text-center">
                    <div class="card-layanan mx-auto">
                        <img src="<?php echo e(asset('img/layanan.png')); ?>" alt="">
                        
                        <h3>Jual</h3>
                        <p>Atur permintaan penjemputan melalui aplikasi, kolektor Upah.com 
                                yang terdekat akan menjemput sampahmu. Ayo ciptakan 
                                Indonesia yang lebih hijau!</p>
                    </div>
                </div>
                <div class="col-md-4 text-center">
                    <div class="card-layanan mx-auto">
                        <img src="<?php echo e(asset('img/layanan.png')); ?>" alt="">
                        <h3>Jual</h3>
                        <p>Atur permintaan penjemputan melalui aplikasi, kolektor Upah.com 
                                yang terdekat akan menjemput sampahmu. Ayo ciptakan 
                                Indonesia yang lebih hijau!</p>
                    </div>
                </div>
                <div class="col-md-4 text-center">
                    <div class="card-layanan mx-auto">
                        <img src="<?php echo e(asset('img/layanan.png')); ?>" alt="">
                        <h3>Jual</h3>
                        <p>Atur permintaan penjemputan melalui aplikasi, kolektor Upah.com 
                                yang terdekat akan menjemput sampahmu. Ayo ciptakan 
                                Indonesia yang lebih hijau!</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <img src="<?php echo e(asset('img/bawah.png')); ?>" alt="" class="end-wave">

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/upah/resources/views/home.blade.php ENDPATH**/ ?>