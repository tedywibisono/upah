<?php $__env->startSection('container'); ?>

<section class="login d-flex">
    <div class="signup-left container w-50 h-100">
        <div class="row justify-content-center align-items-center h-100">
            <div class="col-12">
                <div class="header">
                      <img src="<?php echo e(asset('/img/logo2.png')); ?>" alt="" class="w-50">
                </div>
                <div class="login-form">
                <form action='<?php echo e(url("register")); ?>' method="post">
                    <?php echo csrf_field(); ?>
                    
                    <label for="email" class="form-label">Nama Perusahaan </label>
                    <input type="text"name="perusahaan" class="form-control" id="email" placeholder="Masukkan nama perusahaan/organisasi">

                    <label for="email" class="form-label">Nama </label>
                    <input type="text" name="nama"class="form-control" id="email" placeholder="Masukkan Nama">
                  

                    
                    <label for="email" class="form-label">Provinsi </label>
                    <input type="text"name="provinsi" class="form-control" id="email" placeholder="Masukkan provinsi">
                    
                    <label for="email" class="form-label">Kota </label>
                    <input type="text"name="kota" class="form-control" id="email" placeholder="Masukkan kota">
                    
                    <label for="email" class="form-label">Kecamatan </label>
                    <input type="text"name="kecamatan" class="form-control" id="email" placeholder="Masukkan Kecamatan">
                    
                    <label for="email" class="form-label">Desa </label>
                    <input type="text"name="desa" class="form-control" id="email" placeholder="Masukkan Desa">
                    
                    <label for="email" class="form-label">Rt </label>
                    <input type="text"name="rt" class="form-control" id="email" placeholder="Masukkan Rt">
                    
                    <label for="email" class="form-label">Rw </label>
                    <input type="text"name="rw" class="form-control" id="email" placeholder="Masukkan Rw">
                   
                    <label for="email" class="form-label">Pin</label>
                    <input type="password"name="pin" class="form-control" id="email" placeholder="Masukkan Pin">
                    
                    <label for="email" class="form-label">Email </label>
                    <input type="email"name="email" class="form-control" id="email" placeholder="Masukkan Emain">

                    <label for="Password" class="form-label">Password </label>
                    <input type="Password" name="password" class="form-control" id="Password" placeholder="Masukkan Password"> 
                    <br>
                
                    <button class="sign-in" type="submit">Daftar</button>
                </form>
                    <div class="text-center">
                        <span class="d-inline">Already have an account?<a href="<?php echo e(url('login')); ?>" class="d-inline">Sign in</a></span>

                    </div>
                </div>

            </div>
        </div>
        
        
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.orimain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/upah/resources/views/signup.blade.php ENDPATH**/ ?>