<?php $__env->startSection('container'); ?>
<section class="login d-flex">
    <div class="login-left w-50 h-100 ">
        <img src="<?php echo e(asset('/img/login.png')); ?>" alt="">
    </div>
    <div class="login-right  w-50 ">
        <div class="row justify-content-center  ">
            <div class="col-6 ">
                <div class="header">
                    <h1>Welcome back</h1>
                    <p>Welcome back! Please enter your details.</p>
                </div>
                <div class="login-form ">
                    <form action="<?php echo e(url('daftar')); ?>" method="post">

                        <?php echo csrf_field(); ?>
                        <div class="">
                            <label for="email" class="form-label">Email </label>
                            <input type="email" name="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" placeholder="Enter your email" required value="<?php echo e(old('email')); ?>">                            
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <div>
                            <label for="Password" class="form-label">Password </label>
                            <input type="Password"name="password"class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="Password" placeholder="Enter your password">
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <a href="#" class="text-decoration-none text-center">Forgot password</a>
                        <button class="sign-in"name="signin" type="submit">Login</button>
                    </form>
                   
                    <div class="text-center">
                        <span class="d-inline">buat akun mitra?<a href=<?php echo e(url('signup')); ?> class="d-inline">Sign up for free</a></span>

                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.orimain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/upah/resources/views/login.blade.php ENDPATH**/ ?>