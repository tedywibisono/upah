<?php $__env->startSection('container'); ?>
<?php echo csrf_field(); ?>
<h1>halaman mitra</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.orimain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/upah/resources/views/mitra/mitra.blade.php ENDPATH**/ ?>